import { ReactComponent as LockSVG } from "../assets/svgs/tokenTypes/Lock.svg";
import { ReactComponent as CategorySVG } from "../assets/svgs/tokenTypes/Category.svg";
import { ComponentProps, ReactElement } from "react";
import { SvgIcon } from "@material-ui/core";

export type TokenEl = {
  title: string;
  description: string;
  icon: ReactElement<ComponentProps<typeof SvgIcon>>;
  action: string;
};

export const tokenTypesList: TokenEl[] = [
  {
    title: "Liqudity Tokens",
    description: "UNI-V2 LP Tokens generated from Uniswap Pool",
    icon: <LockSVG />,
    action: "liqudity",
  },
  {
    title: "Project Tokens",
    description: "Regular ERC-20 Project Tokens",
    icon: <CategorySVG />,
    action: "project",
  },
];
