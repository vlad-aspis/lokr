import React, { FC, useCallback, useEffect, useState } from "react";
import TokenCurrencyItem from "../TokenCurrencyItem/TokenCurrencyItem";
import { Grid, makeStyles } from "@material-ui/core";
import LockUnderTitle from "../LockUnderTitle/LockUnderTitle";
import { chains } from "../../constatns/chains";
import { useHistory } from "react-router-dom";
import LockButton from "../LockButton/LockButton";
import { useSelector } from "react-redux";
import { AppStore } from "../../@redux/reducers";

const tokenList = chains;

const useStyles = makeStyles(
  (theme) => ({
    root: {},
    tableContainer: {
      marginBottom: theme.spacing(3),
    },
  }),
  { name: "TokenCurrencyList" }
);

const TokenCurrencyList: FC = () => {
  const classes = useStyles();
  const [chosenCurrency, setChosenCurrency] = useState<string>();
  const [activeItem, setActiveItem] = useState<number>();
  const history = useHistory();
  const chainId = useSelector((state: AppStore) => state.userChainId);
  const [errorMessage, setErrorMessage] = useState<string>();

  useEffect(() => {
    if (chainId && activeItem && activeItem !== chainId) {
      setErrorMessage("You are connected to the wrong chain!");
    } else {
      setErrorMessage(undefined);
    }
  }, [activeItem, chainId]);

  const chooseCurrency = useCallback((name: string) => {
    setChosenCurrency(name.toLowerCase());
  }, []);

  const chooseActiveItem = useCallback((id: number) => {
    setActiveItem(id);
  }, []);

  const onContinue = () => {
    history.push(`/lockups/new/${chosenCurrency}`);
  };

  return (
    <>
      <LockUnderTitle>
        Choose the blockchain that your token you are locking is built on.
      </LockUnderTitle>

      <Grid className={classes.tableContainer} container spacing={2}>
        {tokenList.map((token) => (
          <Grid key={token.id} item>
            <TokenCurrencyItem
              token={token}
              chooseCurrency={chooseCurrency}
              activeItem={activeItem}
              chooseActiveItem={chooseActiveItem}
            />
          </Grid>
        ))}
      </Grid>

      <LockButton
        onClick={onContinue}
        disabled={!chosenCurrency || activeItem !== chainId}
        title={"Continue"}
        errorMessage={errorMessage}
      />
    </>
  );
};

export default TokenCurrencyList;
