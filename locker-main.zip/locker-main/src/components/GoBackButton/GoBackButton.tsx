import React, { FC } from "react";
import ArrowBackRoundedIcon from "@material-ui/icons/ArrowBackRounded";
import { makeStyles, Typography } from "@material-ui/core";
import { useHistory } from "react-router-dom";

const useStyles = makeStyles(
  (theme) => ({
    root: {
      position: "absolute",
      left: -165,
      display: "flex",
      alignItems: "center",
      padding: 10,
      color: theme.palette.common.white,
      backgroundColor: theme.palette.common.white,
      borderRadius: 32,
      cursor: "pointer",
      "&:active": {
        backgroundColor: "#EAE0FF",
      },
      [theme.breakpoints.down("md")]: {
        top: 10,
        left: 10,
        padding: 0,
      },
    },
    arrowContainer: {
      width: 40,
      height: 40,
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      borderRadius: 100,
      backgroundColor: theme.palette.primary.light,
    },
    text: {
      padding: theme.spacing(0, 1.75),
      fontSize: "0.875rem",
      fontWeight: 500,
    },
  }),
  { name: "GoBackButton" }
);

const GoBackButton: FC = () => {
  const classes = useStyles();
  const history = useHistory();

  return (
    <div className={classes.root} onClick={history.goBack}>
      <div className={classes.arrowContainer}>
        <ArrowBackRoundedIcon fontSize="medium" />
      </div>
      <Typography className={classes.text} color="secondary">
        Go Back
      </Typography>
    </div>
  );
};

export default GoBackButton;
