import React, { FC } from "react";
import { Button, makeStyles, Typography } from "@material-ui/core";
import classNames from "classnames";

const useStyles = makeStyles(
  (theme) => ({
    root: {
      marginTop: "auto",
      position: "relative",
    },
    errorMessage: {
      width: 300,
      position: "absolute",
      top: -20,
      color: "red",
      fontSize: "0.75rem",
    },
  }),
  { name: "LockButton" }
);

type LockButtonType = {
  onClick?: () => void;
  disabled?: boolean;
  title: string;
  type?: "submit";
  className?: string;
  size?: "small" | "large" | "medium";
  errorMessage?: string;
};

const LockButton: FC<LockButtonType> = ({
  onClick,
  disabled,
  title,
  type,
  className,
  size,
  errorMessage,
}) => {
  const classes = useStyles();

  return (
    <>
      <Button
        className={classNames(classes.root, className)}
        onClick={onClick}
        disabled={disabled}
        type={type}
        variant="contained"
        color="primary"
        size={size || "large"}
      >
        {disabled && errorMessage && (
          <Typography className={classes.errorMessage}>
            {errorMessage}
          </Typography>
        )}
        {title}
      </Button>
    </>
  );
};

export default LockButton;
