import parse from "csv-parse";

export async function parseCsv(data: string) {
  return new Promise((resolve, reject) => {
    parse(
      data,
      {
        columns: true,
      },
      (err, data) => {
        if (err) reject(err);
        resolve(data);
      }
    );
  });
}
