export function formatValue(value: number | string | undefined, decimals = 0) {
  if (value === undefined) return "";
  try {
    const parts = toFixed(Number(value) / Math.pow(10, decimals))
      .toString()
      .split(".");

    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    return parts.join(".");
  } catch (e) {
    return value;
  }
}

export function toFixed(value: number, count?: number) {
  try {
    return Number(value.toFixed(count || 2)).toString();
  } catch (e) {
    return value;
  }
}
