import { ReactComponent as EthChainLogoSVG } from "../assets/svgs/chains/ethereum.svg";
import { ReactComponent as BSCChainLogoSVG } from "../assets/svgs/chains/binance-coin-bnb-logo.svg";
import { ReactComponent as PolkaSVG } from "../assets/svgs/chains/polka_icon.svg";
import { ReactComponent as CardanoSVG } from "../assets/svgs/chains/cardano_icon.svg";
import { ReactComponent as TronSVG } from "../assets/svgs/chains/tron_icon.svg";
import { SvgIcon } from "@material-ui/core";
import { ComponentProps, ReactElement } from "react";
import {
  LOCKER_BSC_ADDRESS,
  LOCKER_ETH_ADDRESS,
  LOCKER_RINKEBY_ADDRESS,
} from "./env";

export enum Chains {
  MAIN_NET = 1,
  RINKEBY = 4,
  BINANCE = 56,
  POLKA = -1,
  CARDANO = -2,
  TRON = -3,
}

export enum ChainsCurrency {
  ETH = 1,
  RIN = 4,
  BSC = 56,
  POLKA = -1,
  CARDANO = -2,
  TRON = -3,
}

export type Chain = {
  name: string;
  id: number;
  LOCKERAddress: string;
  icon: ReactElement<ComponentProps<typeof SvgIcon>>;
  text: string;
  disable?: boolean;
};

export const chains: Chain[] = [
  {
    name: "Ethereum",
    id: Chains.MAIN_NET,
    LOCKERAddress: LOCKER_ETH_ADDRESS,
    icon: <EthChainLogoSVG />,
    text: "Choose if your coin is an ERC-20 Token",
  },
  {
    name: "BEP-20",
    id: Chains.BINANCE,
    LOCKERAddress: LOCKER_BSC_ADDRESS,
    icon: <BSCChainLogoSVG />,
    text: "Choose if your coin is an BEP-20 Token",
  },
  {
    name: "Rinkeby TEST",
    id: Chains.RINKEBY,
    LOCKERAddress: LOCKER_RINKEBY_ADDRESS,
    icon: <EthChainLogoSVG />,
    text: "Choose if your coin is an ERC-20 Token",
  },
  {
    name: "Polka",
    id: Chains.POLKA,
    LOCKERAddress: LOCKER_RINKEBY_ADDRESS,
    icon: <PolkaSVG />,
    text: "Coming soon",
    disable: true,
  },
  {
    name: "Cardano",
    id: Chains.CARDANO,
    LOCKERAddress: LOCKER_RINKEBY_ADDRESS,
    icon: <CardanoSVG />,
    text: "Coming soon",
    disable: true,
  },
  {
    name: "Tron",
    id: Chains.TRON,
    LOCKERAddress: LOCKER_RINKEBY_ADDRESS,
    icon: <TronSVG />,
    text: "Coming soon",
    disable: true,
  },
];
