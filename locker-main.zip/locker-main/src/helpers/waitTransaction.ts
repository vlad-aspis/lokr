import { ContractTransaction } from "@ethersproject/contracts";

export async function waitTransaction(promise: Promise<ContractTransaction>) {
    const transaction = await promise;
    await transaction.wait();
}
