import { Account } from "./Account";
import { Service } from "./Service";

export class API {
  static Account = new Account();
  static Service = new Service();
}
