import React, { FC } from "react";
import { Checkbox, SvgIcon } from "@material-ui/core";
import { ReactComponent as CheckboxChecked } from "../../assets/svgs/checkbox-checked.svg";
import { ReactComponent as CheckboxUnchecked } from "../../assets/svgs/checkbox-unchecked.svg";

type LockCheckboxType = {
  onClick?: () => void;
  onChange?: (e: any) => void;
  checked: boolean;
  className?: any;
  disabled?: boolean;
};

const LockCheckbox: FC<LockCheckboxType> = ({
  onClick,
  onChange,
  checked,
  className,
  disabled,
}) => {
  return (
    <>
      <Checkbox
        icon={
          <SvgIcon
            style={{ fill: "none" }}
            viewBox="0 0 28 28"
            component={CheckboxUnchecked}
          />
        }
        checkedIcon={
          <SvgIcon viewBox="0 0 26 26" component={CheckboxChecked} />
        }
        onClick={onClick}
        onChange={onChange}
        checked={checked}
        className={className}
        inputProps={{ "aria-label": "secondary checkbox" }}
        disabled={disabled}
      />
    </>
  );
};

export default LockCheckbox;
