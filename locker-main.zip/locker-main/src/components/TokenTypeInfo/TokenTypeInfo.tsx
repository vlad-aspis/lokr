import React, { FC } from "react";
import { TokenEl } from "../../constatns/tokenTypes";
import { makeStyles, Typography } from "@material-ui/core";
import { tableHover, titleFont } from "../../styles/variables";
import LockCheckbox from "../LockCheckbox/LockCheckbox";
import classNames from "classnames";

const useStyles = makeStyles(
  (theme) => ({
    root: {
      display: "flex",
      justifyContent: "space-between",
      padding: theme.spacing(2.5, 2),
      border: "1px solid #F7F7F7",
      borderRadius: 12,
      cursor: "pointer",
      "&:hover": {
        ...tableHover,
      },
    },
    active: {
      ...tableHover,
    },
    item: {
      display: "flex",
    },
    iconContainer: {
      width: 50,
      height: 50,
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      backgroundColor: "#F7F7F7",
      borderRadius: 50,
      marginRight: theme.spacing(2),
    },
    infoContainer: {
      display: "flex",
      flexDirection: "column",
      justifyContent: "center",
    },
    title: {
      ...titleFont,
      marginBottom: theme.spacing(0.5),
    },
  }),
  { name: "TokenType" }
);

type TokenTypeInfoType = {
  chooseTokenType: (action: string) => void;
  tokenType: string | null;
} & TokenEl;

const TokenTypeInfo: FC<TokenTypeInfoType> = ({
  title,
  description,
  icon,
  action,
  chooseTokenType,
  tokenType,
}) => {
  const classes = useStyles();

  return (
    <div
      className={classNames(
        classes.root,
        action === tokenType && classes.active
      )}
      onClick={() => chooseTokenType(action)}
    >
      <div className={classes.item}>
        <div className={classes.iconContainer}>{icon}</div>
        <div className={classes.infoContainer}>
          <Typography className={classes.title}>{title}</Typography>
          <Typography variant="body2">{description}</Typography>
        </div>
      </div>
      <LockCheckbox checked={action === tokenType} />
    </div>
  );
};

export default TokenTypeInfo;
