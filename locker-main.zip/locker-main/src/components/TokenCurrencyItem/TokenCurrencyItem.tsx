import React, { FC } from "react";
import { makeStyles, SvgIcon, Typography } from "@material-ui/core";
import { Chain } from "../../constatns/chains";
import classNames from "classnames";
import { tableHover, titleFont } from "../../styles/variables";
import LockCheckbox from "../LockCheckbox/LockCheckbox";

const useStyles = makeStyles(
  (theme) => ({
    root: {
      width: 145,
      height: 140,
      padding: theme.spacing(1.5),
      position: "relative",
      border: "1px solid #F7F7F7",
      borderRadius: 12,
    },
    rootHover: {
      cursor: "pointer",
      "&:hover": {
        ...tableHover,
      },
    },
    rootActive: {
      border: "1px solid #8563F1",
      boxShadow: "0px 10px 20px -10px rgba(15, 15, 15, 0.1)",
      borderRadius: 12,
    },
    checkbox: {
      position: "absolute",
      top: 6,
      right: 6,
    },
    name: {
      ...titleFont,
      marginTop: theme.spacing(1.25),
      marginBottom: theme.spacing(1.5),
    },
    disable: {
      backgroundColor: "#f6f3f3",
    },
  }),
  { name: "tokenCurrencyItem" }
);

type TokenType = {
  token: Chain;
  chooseCurrency: (name: string) => void;
  activeItem?: number;
  chooseActiveItem: (id: number) => void;
};

const TokenCurrencyItem: FC<TokenType> = ({
  token,
  chooseCurrency,
  activeItem,
  chooseActiveItem,
}) => {
  const { id, icon, name, text, disable } = token;

  const classes = useStyles();
  return (
    <div
      className={classNames(
        classes.root,
        !disable && classes.rootHover,
        activeItem === id && classes.rootActive,
        disable && classes.disable
      )}
      onClick={() => {
        if (disable) return;
        chooseCurrency(name);
        chooseActiveItem(id);
      }}
    >
      <LockCheckbox
        checked={activeItem === id}
        disabled={disable}
        className={classes.checkbox}
      />
      <SvgIcon fontSize="large">{icon}</SvgIcon>
      <Typography className={classes.name}>{name}</Typography>
      <Typography variant="body2">{text}</Typography>
    </div>
  );
};

export default TokenCurrencyItem;
