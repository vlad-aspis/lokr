import { provider } from "../../helpers/provider";
import { toLowBN } from "../../helpers/toBN";

export class Account {
  public async getAccount(): Promise<string | undefined> {
    const accounts = await provider!.listAccounts();
    return accounts[0];
  }

  public async getChainId(): Promise<number> {
    const network = await provider!.getNetwork();
    return network.chainId;
  }

  public async getBalance(address: string): Promise<number> {
    const balance = await provider!.getBalance(address);
    return toLowBN(balance).toNumber();
  }
}
