import { ethers } from "ethers";
import { API } from "../core/api/API";
import { setUserAddress, setUserChain } from "../@redux/actions";
import web3Modal from "./web3modal";
import { getStore } from "../@redux/store";

export let provider: ethers.providers.Web3Provider | null = null;
let currentWeb3Provider: any;

export const initProvider = async (web3Provider: any) => {
  provider = new ethers.providers.Web3Provider(web3Provider);
  currentWeb3Provider = web3Provider;
  const store = await getStore();
  store.dispatch(setUserAddress(await API.Account.getAccount()));
  store.dispatch(setUserChain(await API.Account.getChainId()));

  web3Provider.on("accountsChanged", (data: any) => {
    store.dispatch(setUserAddress(data[0] && ethers.utils.getAddress(data[0])));
    if (!data[0]) {
      onDisconnect();
    }
  });
  web3Provider.on("chainChanged", async (data: any) => {
    provider = new ethers.providers.Web3Provider(web3Provider);
    store.dispatch(setUserChain(await API.Account.getChainId()));
  });

  web3Provider.on("disconnect", async (code: number, reason: string) => {
    onDisconnect();
  });
};

export const disconnect = async () => {
  if ((provider?.provider as any).disconnect) {
    (provider?.provider as any).disconnect();
  } else {
    onDisconnect();
  }
};

const onDisconnect = async () => {
  web3Modal.clearCachedProvider();
  const store = await getStore();
  store.dispatch(setUserChain());
  store.dispatch(setUserAddress());
  provider = null;
  currentWeb3Provider?.removeAllListeners();
};
