import React, { FC, useEffect, useState } from "react";
import {
  Button,
  Link,
  makeStyles,
  MenuItem,
  Select,
  TextField,
  Typography,
} from "@material-ui/core";
import InfoIcon from "../../components/InfoIcon/InfoIcon";
import classNames from "classnames";
import { ReactComponent as DocsSVG } from "../../assets/svgs/icon_file.svg";
import LockCheckbox from "../../components/LockCheckbox/LockCheckbox";
import LockButton from "../../components/LockButton/LockButton";
import { BasePeriod, BasePeriodMilliseconds } from "../../constatns/basePeriod";
import { Controller, useForm } from "react-hook-form";
import { useDropzone } from "react-dropzone";
import { readFile } from "../../helpers/readFile";
import { parseCsv } from "../../helpers/parseCsv";
import { ethers } from "ethers";
import { Chain, chains } from "../../constatns/chains";
import { useHistory, useParams } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { AppStore } from "../../@redux/reducers";
import { shortenWalletAddress } from "../../helpers/shortenWalletAddress";
import { useMutation, useQuery } from "react-query";
import { API } from "../../core/api/API";
import { waitTransaction } from "../../helpers/waitTransaction";
import { setIsLoading, setSuccessfulLock } from "../../@redux/actions";
import BigNumber from "bignumber.js";
import exampleCsv from "../../assets/files/example.csv";

const useStyles = makeStyles(
  (theme) => ({
    root: {},
    formWrapper: {
      width: "100%",
    },
    lockAmountContainer: {
      width: "100%",
      padding: "18px 16px 25px",
      display: "flex",
      marginTop: theme.spacing(0.75),
      marginBottom: theme.spacing(3),

      backgroundColor: "#F6F4FE",
      borderRadius: 6,
    },
    lockAmountItem: {
      display: "flex",
      flexDirection: "column",
      flex: "1 1 50%",
      "&:not(:last-child)": {
        paddingRight: 15,
        marginRight: 15,
        borderRight: "1px solid #EAE0FF",
      },
      "&:last-child": {
        alignItems: "flex-end",
      },
    },
    lockAmountHeaderContainer: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      marginBottom: 15,
      minHeight: 28,
    },
    maxBtn: {
      padding: 4,
      textTransform: "uppercase",
      color: "#5538EE",
      fontWeight: 500,
      backgroundColor: "#EAE0FF",
      borderRadius: 6,
      cursor: "pointer",
    },
    tokenName: {
      fontWeight: 600,
    },
    dateInputContainer: {
      display: "flex",
      marginBottom: theme.spacing(2.5),
      [theme.breakpoints.down("md")]: {
        flexDirection: "column",
      },
    },
    lockDateInputsContainer: {
      minWidth: 145,
      minHeight: 88,
      display: "flex",
      flexDirection: "column",
      "&:not(:last-child)": {
        marginRight: theme.spacing(2.5),
      },
      [theme.breakpoints.down("md")]: {
        width: "100%",
        marginBottom: theme.spacing(0.75),
      },
    },
    lockDateInputsContainerHeaderContainer: {
      display: "flex",
      alignItems: "center",
      marginBottom: theme.spacing(1),
    },
    lockDateInputsContainerHeaderTitle: {
      marginRight: 5,
      fontWeight: 500,
      fontSize: "0.875rem",
    },
    lockInfoText: {
      maxWidth: 410,
      alignSelf: "flex-start",
      fontSize: "0.875rem",
      paddingBottom: theme.spacing(3.25),
    },
    containerWidth: {
      width: "100%",
    },
    benefHeaderContainer: {
      display: "flex",
      alignItems: "center",
    },
    title: {
      marginRight: 5,
      fontWeight: 600,
      fontSize: "1.25rem",
      color: "#0A052D",
    },
    benefUnderTitleContainer: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      minWidth: 42,
      paddingBottom: theme.spacing(2.5),
    },
    beneUnderTitle: {
      fontSize: "0.875rem",
    },
    beneUnderTitleInvalid: {
      color: theme.palette.error.main,
      [theme.breakpoints.down("xs")]: {
        maxWidth: 178,
      },
    },
    fileBtn: {
      border: `1px solid ${theme.palette.primary.main}`,
    },
    fileBtnInvalid: {
      color: theme.palette.error.light,
      border: `1px solid ${theme.palette.error.light}`,
      "&:hover": {
        backgroundColor: theme.palette.error.main,
      },
    },
    userAddressesContainer: {
      height: 160,
      padding: theme.spacing(1.5, 2.5),
      marginBottom: theme.spacing(1.25),
      backgroundColor: "#FAFAFF",
      borderRadius: 6,
      overflow: "auto",
      scrollbarWidth: "none",

      "&::-webkit-scrollbar": {
        width: 3,
        background: "#F6F4FE",
        borderRadius: 10,
      },

      "&::-webkit-scrollbar-thumb": {
        background: "#8563F1",
        borderRadius: 10,
      },
    },
    userAddressesContainerInvalid: {
      height: "auto",
      maxHeight: 270,
      backgroundColor: "#FFF9F9",
      marginBottom: theme.spacing(2.5),
      "&::-webkit-scrollbar": {
        background: "#FCE4E4",
      },

      "&::-webkit-scrollbar-thumb": {
        background: "#E92856",
      },
    },
    userAddressesItem: {
      fontWeight: 500,
      "&:not(:last-child)": {
        marginBottom: theme.spacing(1.5),
      },
    },
    userAddressesItemInvalid: {
      color: "#F57279",
    },

    dropFileContainer: {
      width: "100%",
      minHeight: 160,
      padding: theme.spacing(2, 2.5),
      marginBottom: theme.spacing(1.25),
      position: "relative",
      border: "1px dashed #EAE0FF",
      borderRadius: 6,
      cursor: "pointer",
    },
    dropErrorMessage: {
      width: "100%",
      color: "red",
      fontSize: "0.75rem",
      textAlign: "center",
    },
    dropFileRules: {
      display: "flex",
    },
    dropFileRulesCount: {
      marginRight: theme.spacing(1.25),
    },
    dropFileRulesText: {
      color: "#9F9DAA",
    },
    docsIcon: {
      position: "absolute",
      top: "50%",
      left: "50%",
      transform: "translate(-50%, -50%)",
    },
    docsIconText: {
      position: "absolute",
      top: "72%",
      left: "50%",
      transform: "translate(-50%, -50%)",
      minWidth: 320,
      textAlign: "center",
    },
    underDropFileTextContainer: {
      width: "100%",
      marginBottom: theme.spacing(2.5),
      display: "flex",
      justifyContent: "space-between",
    },
    grey: {
      color: "#9F9DAA",
    },
    underDropFileTextLink: {
      color: "#8563F1",
    },
    resultContainer: {
      width: "100%",
      paddingTop: theme.spacing(2.5),
      marginBottom: theme.spacing(2.5),
      borderTop: "1px solid #EDF0F2",
    },
    resultHeader: {
      marginBottom: theme.spacing(1.25),
    },
    resultItem: {
      display: "flex",
      justifyContent: "space-between",
      "&:not(:last-child)": {
        marginBottom: theme.spacing(1.25),
      },
    },
    fs14: {
      fontSize: 14,
    },
    unlimitedContainer: {
      width: "100%",
      display: "flex",
      alignItems: "center",
      marginBottom: theme.spacing(3),
    },
    footerButtonsContainer: {
      width: "100%",
      display: "flex",
      justifyContent: "space-between",
      marginBottom: theme.spacing(2.75),
      position: "relative",
    },
    footerErrorMessage: {
      width: "100%",
      position: "absolute",
      top: -20,
      color: "red",
      fontSize: "0.75rem",
      textAlign: "center",
    },
    footerButtonItem: {
      width: 210,
      "&:not(:last-child)": {
        marginRight: theme.spacing(1),
      },
    },
    footerStepsContainer: {
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
    },
    footerStepsNumber: {
      width: 30,
      height: 30,
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      fontSize: "1rem",
      fontWeight: 500,
      color: "#0A052D",
      background: "#EDF0F2",
      boxShadow: "0px 16px 20px -10px rgba(31, 18, 73, 0.08)",
      borderRadius: 100,
    },
    footerStepsNumberActive: {
      color: "#FFF",
      background: " linear-gradient(180deg, #CEBEFF 0%, #AA93F2 100%)",
    },
    footerStepsLine: {
      width: 205,
      height: 2,
      margin: theme.spacing(0, 2),
      backgroundColor: "#EDF0F2",
      borderRadius: 2,
    },
    footerStepsLineActive: {
      backgroundColor: "#8563F1",
    },
    resultInfoContainer: {
      paddingTop: theme.spacing(2.5),
      marginBottom: theme.spacing(3),
      borderTop: "1px solid #EDF0F2",
    },
    green: {
      color: "#07D334",
    },
    fw500: {
      fontWeight: 500,
    },
  }),
  { name: "ConfigureLockPage" }
);

export type validFileData = {
  address: string;
  percent: number;
  index: number;
};

const ConfigureLockPage: FC = () => {
  const classes = useStyles();

  const [userAddressesWithAmount, setUserAddressesWithAmount] =
    useState<validFileData[]>();
  const [invalidUserAddresses, setInvalidUserAddresses] = useState<number[]>();
  const [isValidAddresses, setIsValidAddresses] = useState<boolean>(false);
  const [chosenChain, setChosenChain] = useState<Chain>();
  const params = useParams() as any;
  const chainId = useSelector((state: AppStore) => state.userChainId);
  const [errorMessage, setErrorMessage] = useState<string>();
  const [dropzoneErrorMessage, setDropzoneErrorMessage] = useState<string>();
  const userAddress = useSelector((state: AppStore) => state.userAddress);
  const dispatch = useDispatch();
  const history = useHistory();

  useEffect(() => {
    if (chosenChain?.id !== chainId) {
      setErrorMessage("You are connected to the wrong chain!");
    } else {
      setErrorMessage(undefined);
    }
  }, [chosenChain, chainId]);

  useEffect(() => {
    const foundChain = chains.find((chain) => {
      return chain.name.toLowerCase() === params.chain;
    });
    setChosenChain(foundChain);
  }, [params]);

  const {
    handleSubmit,
    control,
    watch,
    setValue,
    formState: { isValid },
  } = useForm({
    mode: "onChange",
    defaultValues: {
      lockAmount: 1,
      paymentsAmount: 1,
      basePeriod: BasePeriod.MONTH,
      multiply: 1,
      unlockUnlimited: false,
    },
  });

  const { lockAmount, paymentsAmount, basePeriod, multiply, unlockUnlimited } =
    watch();

  const { getRootProps, getInputProps, open } = useDropzone({
    accept: ".csv",
    maxFiles: 1,

    onDropAccepted: async (files) => {
      const fileObj: any = await fileHandler(files[0]);
      const [validData, notValidData] = fileValidate(fileObj);
      setUserAddressesWithAmount(validData as validFileData[]);
      setInvalidUserAddresses(notValidData as number[]);
    },
  });

  const { data: tokenSymbol } = useQuery(
    ["getTokenSymbol", params.address],
    () => {
      return API.Service.getTokenSymbol(params.address);
    },
    {
      enabled: !!params.address && !!userAddress,
    }
  );

  const { data: tokenBalance } = useQuery(
    ["tokenBalance", params.address, userAddress],
    () => API.Service.getTokenBalance(params.address, userAddress!),
    {
      enabled: !!params.address && !!userAddress,
    }
  );

  const { mutate: approveTokenAmount, isLoading: isLoadingApproveTokenAmount } =
    useMutation(
      async (data: {
        tokenAddress: string;
        amount: number;
        isUnlimited: boolean;
        chainId: number;
      }) => {
        return waitTransaction(
          API.Service.approveTokenToProject(
            data.tokenAddress,
            data.amount,
            data.isUnlimited,
            data.chainId
          )
        ).then(() => refetchIsApproved());
      }
    );

  const { data: isApproved, refetch: refetchIsApproved } = useQuery(
    ["tokenBalance", params.address, userAddress, lockAmount, chainId],
    () =>
      API.Service.checkIsApproved(
        params.address,
        userAddress!,
        lockAmount,
        chainId!
      ),
    {
      enabled: !!params.address && !!userAddress && !!lockAmount && !!chainId,
    }
  );

  const { mutate: lockTokens, isLoading: isLoadingLockTokens } = useMutation(
    (data: {
      tokenAddress: string;
      amount: BigNumber;
      unlockedFrom: string[];
      unlockAmountArray: string[];
      beneficiariesWithShares: validFileData[];
      chainId: number;
    }) => {
      return waitTransaction(
        API.Service.lockTokens(
          data.tokenAddress,
          data.amount,
          data.unlockedFrom,
          data.unlockAmountArray,
          data.beneficiariesWithShares,
          data.chainId
        )
      );
    },
    {
      onSuccess: (data) => {
        dispatch(setSuccessfulLock(lockAmount));
        history.push(history.location.pathname + "/success");
      },
    }
  );

  const checkIsApprove = () => {
    refetchIsApproved();
  };

  const approveLockAmount = () => {
    approveTokenAmount({
      tokenAddress: params.address,
      amount: lockAmount,
      isUnlimited: unlockUnlimited,
      chainId: chainId!,
    });
  };

  const fileHandler = async (file: File) => {
    try {
      const data = await readFile(file);
      return await parseCsv(data as string);
    } catch (e) {
      setDropzoneErrorMessage(e.message);
      console.error(e);
      throw e;
    }
  };

  const fileValidate = (data: any[]) => {
    setDropzoneErrorMessage(undefined);

    if (data.length > 250) {
      setDropzoneErrorMessage("Too much addresses! Limit is 250!");
      return [[], []];
    }

    const valid: validFileData[] = [];
    const notValid: number[] = [];

    let percentSum = 0;

    data.forEach((item: any, index) => {
      const newObject = {
        ...item,
        index,
      };

      if (
        ethers.utils.isAddress(item.address) &&
        typeof +item.percent === "number" &&
        !isNaN(+item.percent) &&
        (item.percent * 100) % 1 === 0
      ) {
        percentSum += +item.percent;
        valid.push(newObject);
      } else {
        notValid.push(newObject.index);
      }
    });

    if (percentSum !== 100) {
      setDropzoneErrorMessage("Total items percent not equal 100!");
    }

    return [valid, notValid];
  };

  const deleteInvalidAddresses = () => {
    setInvalidUserAddresses([]);
  };

  const roundToTwoDecimals = (data: number) => {
    return Math.round(data * 100) / 100;
  };

  const putMaxToken = () => {
    setValue("lockAmount", tokenBalance!);
  };

  const showPeriodItems = () => {
    return Object.values(BasePeriod).map((item) => {
      return (
        <MenuItem key={item} value={item}>
          {item}
        </MenuItem>
      );
    });
  };

  const showFirstUnlockDate = (firstDate: number) => {
    const dateObj = new Date(firstDate);
    const day = checkLess10(dateObj.getUTCDate());
    const month = checkLess10(dateObj.getUTCMonth() + 1); //months from 1-12
    const year = dateObj.getUTCFullYear();

    return day + "." + month + "." + year;
  };

  const checkLess10 = (data: number) => {
    return data < 10 ? "0" + data : data;
  };

  const onApproveLock = ({
    lockAmount,
    paymentsAmount,
    basePeriod,
    multiply,
  }: {
    lockAmount: number;
    paymentsAmount: number;
    basePeriod: BasePeriod;
    multiply: number;
  }) => {
    const unlockedFrom = [];
    const unlockAmountArray: string[] = [];
    let newAmount: BigNumber = new BigNumber(0);

    for (let i = 0; i < paymentsAmount; i++) {
      unlockedFrom.push(
        (
          (Date.now() +
            BasePeriodMilliseconds[basePeriod] * multiply * (i + 1)) /
          1000
        ).toFixed(0)
      );
      unlockAmountArray.push(
        new BigNumber(lockAmount).dividedBy(paymentsAmount).toString()
      );
      newAmount = newAmount.plus(
        new BigNumber(lockAmount).dividedBy(paymentsAmount).toString()
      );
    }

    lockTokens({
      tokenAddress: params.address,
      amount: newAmount,
      unlockedFrom: unlockedFrom,
      unlockAmountArray: unlockAmountArray,
      beneficiariesWithShares: userAddressesWithAmount!,
      chainId: chainId!,
    });
  };

  useEffect(() => {
    if (
      userAddressesWithAmount &&
      userAddressesWithAmount.length > 0 &&
      invalidUserAddresses &&
      invalidUserAddresses.length === 0
    ) {
      setIsValidAddresses(true);
    }
  }, [userAddressesWithAmount, invalidUserAddresses]);

  useEffect(() => {
    dispatch(setIsLoading(isLoadingApproveTokenAmount || isLoadingLockTokens));
  }, [isLoadingApproveTokenAmount, isLoadingLockTokens, dispatch]);

  return (
    <>
      <form
        onSubmit={handleSubmit(onApproveLock)}
        noValidate
        autoComplete="off"
        className={classes.formWrapper}
      >
        <div className={classes.lockAmountContainer}>
          <div className={classes.lockAmountItem}>
            <div className={classes.lockAmountHeaderContainer}>
              <Typography variant="body2">Lock Amount</Typography>
              <div className={classes.maxBtn} onClick={putMaxToken}>
                max
              </div>
            </div>
            <div>
              <Controller
                render={(props) => {
                  return (
                    <TextField
                      onChange={(e) => props.field.onChange(e.target.value)}
                      type="number"
                      value={props.field.value}
                      error={!!props.fieldState.error}
                      onBlur={checkIsApprove}
                      InputProps={{ inputProps: { min: 0 } }}
                    />
                  );
                }}
                name="lockAmount"
                control={control}
                rules={{
                  required: "Required",
                  min: 0.00000000000000001,
                  max: tokenBalance,
                }}
              />
            </div>
          </div>
          <div className={classes.lockAmountItem}>
            <div className={classes.lockAmountHeaderContainer}>
              <Typography variant="body2">Balance: {tokenBalance}</Typography>
            </div>
            <div>
              <Typography variant="body1" className={classes.tokenName}>
                {tokenSymbol}
              </Typography>
            </div>
          </div>
        </div>

        <div className={classes.dateInputContainer}>
          <div className={classes.lockDateInputsContainer}>
            <div className={classes.lockDateInputsContainerHeaderContainer}>
              <Typography
                variant="body2"
                className={classes.lockDateInputsContainerHeaderTitle}
              >
                Of payments
              </Typography>
              <InfoIcon info="How many payouts should be done in total?" />
            </div>

            <Controller
              render={(props) => {
                return (
                  <TextField
                    type="number"
                    value={props.field.value}
                    variant="outlined"
                    onChange={(e) =>
                      props.field.onChange(Number(e.target.value))
                    }
                    error={!!props.fieldState.error}
                    InputProps={{ inputProps: { min: 1 } }}
                  />
                );
              }}
              name="paymentsAmount"
              control={control}
              rules={{
                required: "Required",
                min: 1,
              }}
            />
          </div>

          <div className={classes.lockDateInputsContainer}>
            <div className={classes.lockDateInputsContainerHeaderContainer}>
              <Typography
                variant="body2"
                className={classes.lockDateInputsContainerHeaderTitle}
              >
                Base period
              </Typography>
              <InfoIcon info="What's the base period for payouts (hours, days, months or years)?" />
            </div>

            <Controller
              render={(props) => {
                return (
                  <Select
                    value={props.field.value}
                    onChange={(e) => props.field.onChange(e.target.value)}
                    variant="outlined"
                    error={!!props.fieldState.error}
                  >
                    {showPeriodItems()}
                  </Select>
                );
              }}
              name="basePeriod"
              control={control}
              rules={{
                required: "Required",
              }}
            />
          </div>

          <div className={classes.lockDateInputsContainer}>
            <div className={classes.lockDateInputsContainerHeaderContainer}>
              <Typography
                variant="body2"
                className={classes.lockDateInputsContainerHeaderTitle}
              >
                Multiply
              </Typography>
              <InfoIcon info="How many Base Periods between each payout?" />
            </div>{" "}
            <Controller
              render={(props) => {
                return (
                  <TextField
                    value={props.field.value}
                    onChange={(e) => props.field.onChange(e.target.value)}
                    type="number"
                    variant="outlined"
                    error={!!props.fieldState.error}
                    InputProps={{ inputProps: { min: 1 } }}
                  />
                );
              }}
              name="multiply"
              control={control}
              rules={{
                required: "Required",
                min: 1,
              }}
            />
          </div>
        </div>

        <Typography className={classes.lockInfoText} variant="body1">
          You're about to lock {lockAmount} {tokenSymbol} with unlock of{" "}
          {roundToTwoDecimals(lockAmount / paymentsAmount)} {tokenSymbol} each{" "}
          {multiply}{" "}
          {multiply > 1
            ? basePeriod.toLowerCase() + "s"
            : basePeriod.toLowerCase()}{" "}
          for {paymentsAmount * multiply}{" "}
          {paymentsAmount * multiply > 1
            ? basePeriod.toLowerCase() + "s"
            : basePeriod.toLowerCase()}{" "}
          .
        </Typography>

        <div className={classes.containerWidth}>
          <div className={classes.benefHeaderContainer}>
            <Typography className={classes.title}>Beneficiaries:</Typography>
            <InfoIcon info="Insert information manually or upload CSV file with your vesting schedule" />
          </div>

          <div className={classNames(classes.benefUnderTitleContainer)}>
            <Typography variant="body2" className={classes.beneUnderTitle}>
              Addresses with Percent
            </Typography>
            <Button
              variant="contained"
              size="small"
              className={classes.fileBtn}
              onClick={open}
            >
              Upload file
            </Button>
          </div>
        </div>
        {!!dropzoneErrorMessage && (
          <Typography className={classes.dropErrorMessage}>
            {dropzoneErrorMessage}
          </Typography>
        )}

        {userAddressesWithAmount && userAddressesWithAmount.length > 0 ? (
          <div
            {...getRootProps({
              className: classNames("dropzone", classes.userAddressesContainer),
            })}
          >
            <input {...getInputProps()} />
            {userAddressesWithAmount!.map((item) => {
              return (
                <Typography
                  key={item.index + item.address}
                  className={classes.userAddressesItem}
                  variant="body2"
                >
                  {item.index + 1}.{" "}
                  {window.innerWidth > 960
                    ? item.address
                    : shortenWalletAddress(item.address)}
                  , {item.percent}
                </Typography>
              );
            })}
          </div>
        ) : (
          <>
            <div
              {...getRootProps({
                className: classNames("dropzone", classes.dropFileContainer),
              })}
            >
              <div>
                <div className={classes.dropFileRules}>
                  <input {...getInputProps()} />
                  <Typography
                    className={classes.dropFileRulesCount}
                    variant="body2"
                    color="secondary"
                  >
                    1.
                  </Typography>
                  <Typography
                    className={classes.dropFileRulesText}
                    variant="body2"
                  >
                    Insert address and percent, separate with comma
                  </Typography>
                </div>
              </div>

              <DocsSVG className={classes.docsIcon} />
              <Typography
                className={classNames(classes.docsIconText, classes.fw500)}
                color="secondary"
              >
                Drop your files here or click to upload
              </Typography>
            </div>
          </>
        )}

        <div className={classes.underDropFileTextContainer}>
          <Typography className={classes.grey} variant="body2">
            Separated by commas
          </Typography>
          <Link href={exampleCsv} variant="body2" download>
            Download example
          </Link>
        </div>

        {invalidUserAddresses && invalidUserAddresses.length > 0 && (
          <div>
            <div className={classNames(classes.benefUnderTitleContainer)}>
              <Typography
                className={classNames(
                  classes.beneUnderTitle,
                  classes.beneUnderTitleInvalid,
                  classes.fw500
                )}
              >
                The below addresses cannot be processed
              </Typography>
              <Button
                variant="contained"
                size="small"
                className={classNames(classes.fileBtn, classes.fileBtnInvalid)}
                onClick={deleteInvalidAddresses}
              >
                Delete them
              </Button>
            </div>
            <div
              className={classNames(
                classes.userAddressesContainer,
                classes.userAddressesContainerInvalid
              )}
            >
              {invalidUserAddresses!.map((item) => {
                return (
                  <Typography
                    key={item}
                    className={classNames(
                      classes.userAddressesItem,
                      classes.userAddressesItemInvalid
                    )}
                    variant="body2"
                  >
                    Line {item + 1}: NaN is a invalid wallet address or wrong
                    percent
                  </Typography>
                );
              })}
            </div>
          </div>
        )}

        <div className={classes.resultContainer}>
          <Typography
            className={classNames(classes.resultHeader, classes.fw500)}
            color="primary"
          >
            Result:
          </Typography>
          <div className={classes.resultItem}>
            <Typography
              className={classNames(classes.fs14, classes.fw500)}
              color="primary"
            >
              Lock amount:
            </Typography>
            <Typography
              className={classNames(classes.fs14, classes.fw500)}
              color="primary"
            >
              {lockAmount} {tokenSymbol}
            </Typography>
          </div>
          <div className={classes.resultItem}>
            <Typography
              className={classNames(classes.fs14, classes.fw500)}
              color="primary"
            >
              Of payments:
            </Typography>
            <Typography
              className={classNames(classes.fs14, classes.fw500)}
              color="primary"
            >
              {paymentsAmount} payments
            </Typography>
          </div>
          <div className={classes.resultItem}>
            <Typography
              className={classNames(classes.fs14, classes.fw500)}
              color="primary"
            >
              Base period:
            </Typography>
            <Typography
              className={classNames(classes.fs14, classes.fw500)}
              color="primary"
            >
              {basePeriod}
            </Typography>
          </div>
          <div className={classes.resultItem}>
            <Typography
              className={classNames(classes.fs14, classes.fw500)}
              color="primary"
            >
              Multiply:
            </Typography>
            <Typography
              className={classNames(classes.fs14, classes.fw500)}
              color="primary"
            >
              {multiply}
            </Typography>
          </div>
        </div>

        {!isApproved ? (
          <div className={classes.unlimitedContainer}>
            <Controller
              render={(props) => {
                return (
                  <LockCheckbox
                    onChange={(e) => {
                      props.field.onChange(e.target.checked);
                    }}
                    checked={props.field.value}
                  />
                );
              }}
              name="unlockUnlimited"
              control={control}
            />

            <Typography className={classes.fw500} color="primary">
              Approve Unlimited {tokenSymbol}
            </Typography>
          </div>
        ) : (
          <div className={classes.resultInfoContainer}>
            <div className={classes.resultItem}>
              <Typography
                className={classNames(classes.fs14, classes.fw500)}
                color="primary"
              >
                Service Fee:
              </Typography>
              <Typography
                className={classNames(
                  classes.fs14,
                  classes.fw500,
                  classes.green
                )}
              >
                0%
              </Typography>
            </div>
            <div className={classes.resultItem}>
              <Typography
                className={classNames(classes.fs14, classes.fw500)}
                color="primary"
              >
                First Unlock Date:
              </Typography>
              <Typography
                className={classNames(classes.fs14, classes.fw500)}
                color="primary"
              >
                {showFirstUnlockDate(
                  Date.now() + BasePeriodMilliseconds[basePeriod] * multiply
                )}
              </Typography>
            </div>
          </div>
        )}

        <div className={classes.footerButtonsContainer}>
          {!!errorMessage && (
            <Typography className={classes.footerErrorMessage}>
              {errorMessage}
            </Typography>
          )}
          <LockButton
            className={classes.footerButtonItem}
            size="medium"
            title={window.innerWidth >= 960 ? "Approve Lock" : "Approve"}
            type="submit"
            disabled={
              !isValidAddresses ||
              isApproved ||
              isLoadingApproveTokenAmount ||
              chosenChain?.id !== chainId ||
              !!dropzoneErrorMessage ||
              !isValid
            }
            onClick={approveLockAmount}
          />
          <LockButton
            className={classes.footerButtonItem}
            size="medium"
            title={`Lock ${tokenSymbol}`}
            disabled={
              !isValidAddresses ||
              !isApproved ||
              isLoadingLockTokens ||
              chosenChain?.id !== chainId ||
              !!dropzoneErrorMessage ||
              !isValid
            }
            type="submit"
          />
        </div>

        <div className={classes.footerStepsContainer}>
          <div
            className={classNames(
              classes.footerStepsNumber,
              classes.footerStepsNumberActive
            )}
          >
            1
          </div>
          <div
            className={classNames(
              classes.footerStepsLine,
              isApproved && classes.footerStepsLineActive
            )}
          />
          <div
            className={classNames(
              classes.footerStepsNumber,
              isApproved && classes.footerStepsNumberActive
            )}
          >
            2
          </div>
        </div>
      </form>
    </>
  );
};

export default ConfigureLockPage;
