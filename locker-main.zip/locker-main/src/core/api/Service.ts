import { ContractTransaction } from "@ethersproject/contracts";
import { IUniswapPairFactory } from "../../@types/IUniswapPairFactory";
import { Erc20Factory } from "../../@types/Erc20Factory";
import {
  MAX_BIGNUMBER,
  numberToTransactionalNumber,
  toLowBN,
} from "../../helpers/toBN";
import { LockerFactory } from "../../@types/LockerFactory";
import { provider } from "../../helpers/provider";
import { Chains } from "../../constatns/chains";
import { validFileData } from "../../pages/ConfigureLockPage/ConfigureLockPage";
import BigNumber from "bignumber.js";

export const LOCKER_MAIN_NET = "0x9b49411072ff4c2d1c0d2d2f7f166211891aba2d";
export const LOCKER_RINKEBY = "0xF3DFb3928545DF325c60a0273D633331685B2013";

const lockerAddress: { [key: number]: string } = {
  [Chains.MAIN_NET]: LOCKER_MAIN_NET,
  [Chains.RINKEBY]: LOCKER_RINKEBY,
};

export class Service {
  public async checkIsTokenLP(tokenAddress: string) {
    const tokenInstance = IUniswapPairFactory.connect(tokenAddress, provider!);
    try {
      await tokenInstance.token0();
      await tokenInstance.token1();
      return true;
    } catch (e) {
      return false;
    }
  }

  public async getTokenBalance(tokenAddress: string, userAddress: string) {
    const tokenInstance = Erc20Factory.connect(tokenAddress, provider!);
    let decimals;
    try {
      decimals = await tokenInstance.decimals();
    } catch (e) {
      decimals = 18;
    }
    return toLowBN(
      await tokenInstance.balanceOf(userAddress),
      decimals
    ).toNumber();
  }

  public async getTokenSymbol(tokenAddress: string) {
    const tokenInstance = Erc20Factory.connect(tokenAddress, provider!);
    try {
      const symbol = await tokenInstance.symbol();
      return symbol;
    } catch (e) {
      console.error(e);
      return "";
    }
  }

  public async checkIsApproved(
    tokenAddress: string,
    userAddress: string,
    toApprove: number,
    chainId: Chains
  ) {
    const tokenInstance = Erc20Factory.connect(tokenAddress, provider!);
    const allowed = await tokenInstance.allowance(
      userAddress,
      lockerAddress[chainId]
    );
    let decimals;
    try {
      decimals = await tokenInstance.decimals();
    } catch (e) {
      decimals = 18;
    }

    return toApprove <= toLowBN(allowed, decimals).toNumber();
  }

  public async approveTokenToProject(
    tokenAddress: string,
    amount: number,
    isUnlimited: boolean,
    chainId: number
  ): Promise<ContractTransaction> {
    const tokenInstance = Erc20Factory.connect(
      tokenAddress,
      provider!.getSigner()
    );
    if (isUnlimited) {
      return tokenInstance.approve(
        lockerAddress[chainId],
        MAX_BIGNUMBER.toFixed(0)
      );
    }

    let decimals;
    try {
      decimals = await tokenInstance.decimals();
    } catch (e) {
      decimals = 18;
    }

    return tokenInstance.approve(
      lockerAddress[chainId],
      numberToTransactionalNumber(amount, decimals)
    );
  }

  public async lockTokens(
    tokenAddress: string,
    amount: BigNumber,
    unlockedFrom: string[],
    unlockAmountArray: string[],
    beneficiariesWithShares: validFileData[],
    chainId: number
  ) {
    const beneficiaries: string[] = [];
    const shares: number[] = [];
    beneficiariesWithShares.forEach((item) => {
      beneficiaries.push(item.address);
      shares.push(item.percent * 100);
    });

    const lockerInstance = LockerFactory.connect(
      lockerAddress[chainId],
      provider!.getSigner()
    );

    const tokenInstance = Erc20Factory.connect(tokenAddress, provider!);
    let decimals: number;
    try {
      decimals = await tokenInstance.decimals();
    } catch (e) {
      decimals = 18;
    }

    const validUnlockAmountArray = unlockAmountArray.map((item) => {
      return numberToTransactionalNumber(item, decimals);
    });

    return lockerInstance.lockTokens(
      tokenAddress,
      numberToTransactionalNumber(amount.toString(), decimals),
      unlockedFrom,
      validUnlockAmountArray,
      beneficiaries,
      shares
    );
  }
}
