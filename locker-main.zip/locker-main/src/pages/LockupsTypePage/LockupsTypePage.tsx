import React, { FC, useCallback, useEffect, useState } from "react";
import LockUnderTitle from "../../components/LockUnderTitle/LockUnderTitle";
import { Grid } from "@material-ui/core";
import { tokenTypesList } from "../../constatns/tokenTypes";
import TokenTypeInfo from "../../components/TokenTypeInfo/TokenTypeInfo";
import LockButton from "../../components/LockButton/LockButton";
import { useHistory, useParams } from "react-router-dom";
import { Chain, chains } from "../../constatns/chains";
import { useSelector } from "react-redux";
import { AppStore } from "../../@redux/reducers";

const LockupsTypePage: FC = () => {
  const history = useHistory();
  const [tokenType, setTokenType] = useState<string | null>(null);
  const [chosenChain, setChosenChain] = useState<Chain>();
  const params = useParams() as any;
  const chainId = useSelector((state: AppStore) => state.userChainId);
  const [errorMessage, setErrorMessage] = useState<string>();

  useEffect(() => {
    if (chosenChain?.id !== chainId) {
      setErrorMessage("You are connected to the wrong chain!");
    } else {
      setErrorMessage(undefined);
    }
  }, [chosenChain, chainId]);

  useEffect(() => {
    const foundChain = chains.find((chain) => {
      return chain.name.toLowerCase() === params.chain;
    });
    setChosenChain(foundChain);
  }, [params]);

  const chooseTokenType = useCallback((action: string) => {
    setTokenType(action.toLowerCase());
  }, []);

  const onContinue = () => {
    history.push(`${history.location.pathname}/${tokenType}`);
  };

  return (
    <>
      <LockUnderTitle>
        Select the type of token you would like to create a lock for. You can
        create multiple locks with different settings for each one.
      </LockUnderTitle>

      <Grid container spacing={2}>
        {tokenTypesList.map((el) => (
          <Grid xs={12} key={el.title} item>
            <TokenTypeInfo
              title={el.title}
              description={el.description}
              icon={el.icon}
              action={el.action}
              chooseTokenType={chooseTokenType}
              tokenType={tokenType}
            />
          </Grid>
        ))}
      </Grid>

      <LockButton
        onClick={onContinue}
        disabled={!tokenType || chosenChain?.id !== chainId}
        title={"Continue"}
        errorMessage={errorMessage}
      />
    </>
  );
};

export default LockupsTypePage;
