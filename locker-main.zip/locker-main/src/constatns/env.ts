export const LOCKER_ETH_ADDRESS =
  process.env.REACT_APP_LOCKER_ETH_ADDRESS ?? "";
export const LOCKER_BSC_ADDRESS =
  process.env.REACT_APP_LOCKER_BSC_ADDRESS ?? "";
export const LOCKER_RINKEBY_ADDRESS =
  process.env.REACT_APP_LOCKER_RINKEBY_ADDRESS ?? "";

export const NODE_ENV = process.env.NODE_ENV ?? "development";
