import React, { FC } from "react";
import { makeStyles, Tooltip } from "@material-ui/core";
import InfoRoundedIcon from "@material-ui/icons/InfoRounded";

type InfoIconType = {
  info: string;
};

const useStyles = makeStyles(
  (theme) => ({
    infoIcon: {
      cursor: "pointer",
      borderRadius: 50,
      color: "#FFF",
      backgroundColor: theme.palette.primary.main,
      "&:hover": {
        color: theme.palette.primary.main,
        backgroundColor: "#FFF",
      },
    },
  }),
  { name: "InfoIcon" }
);

const InfoIcon: FC<InfoIconType> = ({ info }) => {
  const classes = useStyles();

  return (
    <>
      <Tooltip title={info}>
        <InfoRoundedIcon fontSize="small" className={classes.infoIcon} />
      </Tooltip>
    </>
  );
};

export default InfoIcon;
