import React, { FC } from "react";
import { makeStyles, Typography } from "@material-ui/core";

const useStyles = makeStyles(
  (theme) => ({
    root: {
      maxWidth: 400,
      minHeight: 60,
      paddingBottom: theme.spacing(1.5),
    },
    text: {
      textAlign: "center",
      fontSize: "0.875rem",
    },
  }),
  { name: "LockUnderTitle" }
);

const LockUnderTitle: FC = (props) => {
  const classes = useStyles();
  return (
    <div className={classes.root}>
      <Typography className={classes.text}>{props.children}</Typography>
    </div>
  );
};

export default LockUnderTitle;
