export enum AppActions {
  SET_USER_ADDRESS = "SET_USER_ADDRESS",
  SET_USER_CHAIN = "SET_USER_CHAIN",
  SET_SUCCESSFUL_LOCK = "SET_SUCCESSFUL_LOCK",
  SET_IS_LOADING = "SET_IS_LOADING",
}

export function setUserAddress(address?: string) {
  return { type: AppActions.SET_USER_ADDRESS, address };
}

export function setUserChain(chainId?: number) {
  return { type: AppActions.SET_USER_CHAIN, chainId };
}

export function setSuccessfulLock(amount: number) {
  return { type: AppActions.SET_SUCCESSFUL_LOCK, amount };
}

export function setIsLoading(isLoading: boolean) {
  return { type: AppActions.SET_IS_LOADING, isLoading };
}
