import rootReducer, { AppStore } from "../reducers";
import { AnyAction, createStore, Store } from "redux";
import { provider } from "../../helpers/provider";
import { persistReducer, persistStore } from "redux-persist";
import storage from "redux-persist/lib/storage";
import { API } from "../../core/api/API";

const persistConfig = {
  key: "root",
  storage,
  whitelist: [],
};

let store: Store<AppStore>;

export async function getStore() {
  if (store) return store;
  if (!provider) {
    const persistedReducer = persistReducer(persistConfig, rootReducer);
    store = createStore(persistedReducer);
    persistStore(store);
    return store;
  }

  const initialState: AppStore = {
    userAddress: await API.Account.getAccount(),
    userChainId: await API.Account.getChainId(),
    successedData: {
      amount: 0,
      success: false,
    },
    isLoading: false,
  };

  const persistedReducer = persistReducer(
    persistConfig,
    (state: AppStore = initialState, action: AnyAction) => {
      return rootReducer(state, action);
    }
  );

  store = createStore(persistedReducer);
  persistStore(store);

  return store;
}
