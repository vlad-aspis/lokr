import { AppActions } from "../actions";
import { AnyAction } from "redux";

export interface AppStore {
  userAddress?: string;
  userChainId?: number;
  successedData?: {
    amount: number;
    success: boolean;
  };
  isLoading: boolean;
}

const initialState: AppStore = {
  isLoading: false,
};

const rootReducer = (state = initialState, action: AnyAction) => {
  if (action.type === AppActions.SET_USER_ADDRESS) {
    const auth = {
      userAddress: action.address,
    };
    return { ...state, ...auth };
  }
  if (action.type === AppActions.SET_USER_CHAIN) {
    const chain = {
      userChainId: action.chainId,
    };
    return { ...state, ...chain };
  }
  if (action.type === AppActions.SET_SUCCESSFUL_LOCK) {
    const successedData = {
      amount: action.amount,
      success: true,
    };
    return { ...state, successedData: { ...successedData } };
  }

  if (action.type === AppActions.SET_IS_LOADING) {
    return { ...state, isLoading: action.isLoading };
  }

  return state;
};

export default rootReducer;
