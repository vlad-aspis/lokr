import React, { useEffect, useState } from "react";
import LockUnderTitle from "../../components/LockUnderTitle/LockUnderTitle";
import { makeStyles, TextField, Typography } from "@material-ui/core";
import { ReactComponent as SearchSVG } from "../../assets/svgs/loupe.svg";
import LockButton from "../../components/LockButton/LockButton";
import { useHistory, useParams } from "react-router-dom";
import { Controller, useForm } from "react-hook-form";
import { useSelector } from "react-redux";
import { AppStore } from "../../@redux/reducers";
import { Chain, chains } from "../../constatns/chains";
import { ethers } from "ethers";
import InputAdornment from "@material-ui/core/InputAdornment";
import { useQuery } from "react-query";
import { API } from "../../core/api/API";

type addressInput = {
  address: string;
};

const useStyles = makeStyles(
  (theme) => ({
    root: {
      width: "100%",
      flex: "1 1 100%",
      display: "flex",
      flexDirection: "column",
    },
    form: {
      display: "flex",
      flexDirection: "column",
      alignItems: "flex-start",
      flex: "1 1 auto",
      position: "relative",
    },
    formInput: {
      width: "100%",
      marginBottom: theme.spacing(1),
    },
    purple: {
      color: theme.palette.primary.main,
    },
    infoMessage: {
      width: "100%",
      position: "absolute",
      bottom: 74,
      textAlign: "center",
    },
    formButton: {
      alignSelf: "center",
    },
  }),
  { name: "LockupsAddressPage" }
);

const LockupsAddressPage = () => {
  const classes = useStyles();
  const history = useHistory();
  const [chosenChain, setChosenChain] = useState<Chain>();
  const params = useParams() as any;
  const chainId = useSelector((state: AppStore) => state.userChainId);
  const [errorMessage, setErrorMessage] = useState<string>();
  const [infoMessage, setInfoMessage] = useState<string>();

  useEffect(() => {
    if (chosenChain?.id !== chainId) {
      setErrorMessage("You are connected to the wrong chain!");
    } else {
      setErrorMessage(undefined);
    }
  }, [chosenChain, chainId]);

  useEffect(() => {
    const foundChain = chains.find((chain) => {
      return chain.name.toLowerCase() === params.chain;
    });
    setChosenChain(foundChain);
  }, [params]);

  const { handleSubmit, control, watch } = useForm<addressInput>({
    defaultValues: {
      address: "",
    },
  });

  const address = watch("address");

  const { data } = useQuery(
    ["checkIsTokenLP", address],
    () => API.Service.checkIsTokenLP(address),
    {
      enabled: !ethers.utils.isAddress(address),
    }
  );

  const { data: checkValidToken } = useQuery(
    ["checkIsValidToken", address],
    () => API.Service.getTokenSymbol(address),
    {
      enabled: ethers.utils.isAddress(address) && !!address,
    }
  );

  useEffect(() => {
    if (!ethers.utils.isAddress(address)) {
      setErrorMessage("Invalid address!");
      setInfoMessage(undefined);
    } else if (!checkValidToken) {
      setErrorMessage("Address is not ERC20 token!");
      setInfoMessage(undefined);
    } else {
      setErrorMessage(undefined);

      if (params.type === "liqudity" && !data) {
        setInfoMessage("Token is not LP token");
      } else {
        setInfoMessage(undefined);
      }
    }
  }, [address, data, checkValidToken, params.type]);

  const onContinue = ({ address }: addressInput) => {
    history.push(`${history.location.pathname}/${address}`);
  };

  return (
    <>
      <LockUnderTitle>
        Enter The Token address you would like to lock for
      </LockUnderTitle>

      <div className={classes.root}>
        <form
          onSubmit={handleSubmit(onContinue)}
          className={classes.form}
          noValidate
          autoComplete="off"
        >
          <Controller
            render={(props) => {
              return (
                <TextField
                  className={classes.formInput}
                  label="Address"
                  variant="outlined"
                  fullWidth
                  onChange={(e) => {
                    props.field.onChange(e.target.value);
                  }}
                  InputProps={{
                    endAdornment: (
                      <InputAdornment position="end">
                        <SearchSVG />
                      </InputAdornment>
                    ),
                  }}
                />
              );
            }}
            name="address"
            control={control}
            rules={{
              required: "Required",
            }}
          />

          <Typography variant="body2">
            e.g.{" "}
            <span className={classes.purple}>
              0x01547ef97f9140dbdf5ae50f06b77337b95cf4bb
            </span>
          </Typography>

          {!!infoMessage && (
            <Typography
              className={classes.infoMessage}
              variant="body2"
              color="error"
            >
              {infoMessage}
            </Typography>
          )}
          <LockButton
            className={classes.formButton}
            type="submit"
            title={"Continue"}
            disabled={
              address.length === 0 ||
              !!errorMessage ||
              chosenChain?.id !== chainId
            }
            errorMessage={errorMessage}
          />
        </form>
      </div>
    </>
  );
};

export default LockupsAddressPage;
