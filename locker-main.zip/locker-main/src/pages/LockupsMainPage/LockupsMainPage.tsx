import React, { FC } from "react";
import { Button, Grid, makeStyles, Typography } from "@material-ui/core";
import NewLockWrapper from "../../components/NewLockWrapper/NewLockWrapper";
import TokenCurrencyList from "../../components/TokenCurrencyList/TokenCurrencyList";

const useStyles = makeStyles(
  (theme) => ({
    root: {
      display: "flex",
    },
    leftPart: {
      display: "flex",
      flexDirection: "column",
      justifyContent: "center",
      alignItems: "flex-start",
      [theme.breakpoints.down("md")]: {
        justifyContent: "center",
        alignItems: "center",
      },
    },
    title: {
      marginBottom: theme.spacing(4),
      [theme.breakpoints.down("md")]: {
        textAlign: "center",
      },
      [theme.breakpoints.down("sm")]: {
        fontSize: "2.625rem",
      },
    },
    underTitle: {
      marginBottom: theme.spacing(8),
      maxWidth: 440,
      fontWeight: 500,
      fontSize: "1.125rem",
      [theme.breakpoints.down("md")]: {
        textAlign: "center",
      },
    },
  }),
  { name: "LockupsMainPage" }
);

const LockupsMainPage: FC = () => {
  const classes = useStyles();
  return (
    <Grid container spacing={3} className={classes.root}>
      <Grid item md={6} xs={12} className={classes.leftPart}>
        <Typography className={classes.title} variant="h1" component="h2">
          Create custom token lock instantly
        </Typography>
        <Typography className={classes.underTitle}>
          All coins are locked into our audited smart contract and can only be
          withdrawn by you after lock time expires
        </Typography>
        <Button
          href="https://rinkeby.etherscan.io/address/0xF3DFb3928545DF325c60a0273D633331685B2013#code"
          target="_blank"
          variant="contained"
          size="large"
        >
          Explore Contract
        </Button>
      </Grid>
      <Grid item md={6} xs={12}>
        <NewLockWrapper mainPage>
          <TokenCurrencyList />
        </NewLockWrapper>
      </Grid>
    </Grid>
  );
};

export default LockupsMainPage;
