import { Button, Link, makeStyles, Tooltip } from "@material-ui/core";
import React from "react";
import { useHistory, useLocation } from "react-router-dom";
import { navMenu } from "../../constatns/navMenu";
import classNames from "classnames";

const useStyles = makeStyles(
  (theme) => ({
    root: {
      display: "flex",
      justifyContent: "space-around",
      alignItems: "center",
      "&>:not(:last-child)": {
        marginRight: theme.spacing(1),
      },
      [theme.breakpoints.down("md")]: {
        display: "none",
      },
    },
    button: {
      padding: "12px 32px",
    },
    active: {
      backgroundColor: "transparent",
      color: theme.palette.primary.main,
      boxShadow: `0 0 0 1px ${theme.palette.primary.main}`,
    },
  }),
  { name: "mainHeader" }
);

const AppbarNavigation = () => {
  const classes = useStyles();
  const location = useLocation();
  const history = useHistory();

  const isActive = (path: string): boolean => {
    return location.pathname.indexOf(path) > 0;
  };

  const handleClick = (path: string) => {
    history.push("/" + path);
  };

  return (
    <>
      <div className={classes.root}>
        {navMenu.map((item) => {
          if (item.link) {
            return (
              <Link key={item.title} href={item.link} target="_blank">
                <Button
                  className={classNames(
                    classes.button,
                    isActive(item.path) && classes.active
                  )}
                >
                  {item.title}
                </Button>
              </Link>
            );
          }

          return (
            <span key={item.title}>
              {item.disable ? (
                <Tooltip title="coming soon">
                  <span>
                    <Button
                      onClick={handleClick.bind(null, item.path)}
                      className={classNames(
                        classes.button,
                        isActive(item.path) && classes.active
                      )}
                      disabled={item.disable}
                    >
                      {item.title}
                    </Button>
                  </span>
                </Tooltip>
              ) : (
                <Button
                  onClick={handleClick.bind(null, item.path)}
                  className={classNames(
                    classes.button,
                    isActive(item.path) && classes.active
                  )}
                >
                  {item.title}
                </Button>
              )}
            </span>
          );
        })}
      </div>
    </>
  );
};

export default AppbarNavigation;
