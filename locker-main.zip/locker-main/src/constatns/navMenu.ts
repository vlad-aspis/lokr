export const navMenu = [
  {
    title: "Explore",
    path: "explore",
    // disable: true,
    link: "https://info.aspis.finance/",
  },
  {
    title: "About",
    path: "about",
    // disable: true,
    link: "https://aspis.finance/",
  },
  {
    title: "Lock",
    path: "lockups",
  },
  {
    title: "Buy & Sell",
    path: "buy&sell",
    disable: true,
  },
];
