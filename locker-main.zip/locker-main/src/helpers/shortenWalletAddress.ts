export const shortenWalletAddress = (address: string) => {
    const firstPart = address.slice(0, 4);
    const lastPart = address.slice(address.length - 4, address.length + 1);
    return `${firstPart}...${lastPart}`;
}
