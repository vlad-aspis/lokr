import React from "react";
import AppbarHeader from "../AppbarHeader/AppbarHeader";
import AppRouter from "../../router/AppRouter";
import { CircularProgress, Container, makeStyles } from "@material-ui/core";
import { useSelector } from "react-redux";
import { AppStore } from "../../@redux/reducers";

const useStylesOverlay = makeStyles(
  (theme) => {
    return {
      root: {
        position: "absolute",
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        background: theme.palette.action.hover,
        backdropFilter: "blur(4px)",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        zIndex: 1101,
        borderRadius: theme.shape.borderRadius,
      },
    };
  },
  { name: "LockerOverlay" }
);

const App = () => {
  const loading = useSelector((state: AppStore) => state.isLoading);

  const OverlayLoading = (props: { loading: boolean }) => {
    const classes = useStylesOverlay();
    return props.loading ? (
      <div className={classes.root}>
        <CircularProgress />
      </div>
    ) : null;
  };

  return (
    <>
      <OverlayLoading loading={loading} />
      <AppbarHeader />
      <Container maxWidth="lg">
        <AppRouter />
      </Container>
    </>
  );
};

export default App;
