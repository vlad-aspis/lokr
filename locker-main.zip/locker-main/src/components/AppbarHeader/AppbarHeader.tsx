import React, { useState } from "react";
import {
  AppBar,
  Button,
  Container,
  Fade,
  Link,
  makeStyles,
  Menu,
  MenuItem,
  Toolbar,
} from "@material-ui/core";
import Logo from "../../assets/svgs/logo.svg";
import AppbarNavigation from "../AppbarNavigation/AppbarNavigation";
import AppbarHeaderWalletInfo from "../AppbarHeaderWalletInfo/AppbarHeaderWalletInfo";
import classNames from "classnames";
import { navMenu } from "../../constatns/navMenu";
import { useHistory, useLocation } from "react-router-dom";

const useStyles = makeStyles(
  (theme) => ({
    contentWrapper: {
      padding: theme.spacing(1, 0),
    },
    toolbar: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
    },
    logoContainer: {
      width: 170,
    },
    rootPhone: {
      display: "none",
      [theme.breakpoints.down("md")]: {
        display: "flex",
        justifyContent: "center",
      },
    },
    button: {
      padding: "12px 32px",
    },
    menu: {
      color: theme.palette.primary.main,
    },
    active: {
      backgroundColor: "transparent",
      color: theme.palette.primary.main,
      boxShadow: `0 0 0 1px ${theme.palette.primary.main}`,
    },
  }),
  { name: "mainHeader" }
);

const AppbarHeader = () => {
  const classes = useStyles();
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const open = Boolean(anchorEl);
  const location = useLocation();
  const history = useHistory();

  const handleMenu = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const isActive = (path: string): boolean => {
    return location.pathname.indexOf(path) > 0;
  };

  const handleClick = (path: string) => {
    history.push("/" + path);
  };

  return (
    <>
      <AppBar position="static" color="transparent" elevation={0}>
        <Container className={classes.contentWrapper}>
          <Toolbar className={classes.toolbar}>
            <Link
              href={"https://aspis.finance/"}
              target={"_blank"}
              className={classes.logoContainer}
            >
              <img style={{ width: "100%" }} src={Logo} alt="logo" />
            </Link>
            <AppbarNavigation />
            <AppbarHeaderWalletInfo />
          </Toolbar>

          <div className={classes.rootPhone}>
            <Button
              aria-expanded={open ? "true" : undefined}
              onClick={handleMenu}
              className={classNames(classes.button, classes.menu)}
            >
              Menu
            </Button>

            <Menu
              id="fade-menu"
              MenuListProps={{
                "aria-labelledby": "fade-button",
              }}
              anchorEl={anchorEl}
              open={open}
              onClose={handleClose}
              TransitionComponent={Fade}
            >
              {navMenu.map((item) => {
                if (item.link) {
                  return (
                    <MenuItem
                      key={item.title}
                      className={classNames(
                        classes.button,
                        isActive(item.path) && classes.active
                      )}
                      disabled={item.disable}
                    >
                      <Link href={item.link} target="_blank">
                        {item.title}
                      </Link>
                    </MenuItem>
                  );
                }
                return (
                  <MenuItem
                    key={item.title}
                    onClick={() => {
                      handleClick(item.path);
                      handleClose();
                    }}
                    className={classNames(
                      classes.button,
                      isActive(item.path) && classes.active
                    )}
                    disabled={item.disable}
                  >
                    {item.title}
                  </MenuItem>
                );
              })}
            </Menu>
          </div>
        </Container>
      </AppBar>
    </>
  );
};

export default AppbarHeader;
