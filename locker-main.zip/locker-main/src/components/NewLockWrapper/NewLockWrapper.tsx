import { makeStyles, Typography } from "@material-ui/core";
import React, { FC } from "react";
import LockIcon from "../../assets/svgs/icon_top_lock.svg";
import GoBackButton from "../GoBackButton/GoBackButton";

type NewLockProps = {
  mainPage?: boolean;
  configure?: boolean;
};

const useStyles = makeStyles(
  (theme) => ({
    root: {
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      width: 555,
      margin: `0 auto 40px`,
      position: "relative",
      [theme.breakpoints.down("xs")]: {
        width: 350,
      },
    },
    cardContainer: {
      width: "100%",
      minHeight: 640,
      padding: "20px 40px 28px",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      backgroundColor: "#FFFFFF",
      borderRadius: 32,
      marginBottom: theme.spacing(2),
      [theme.breakpoints.down("xs")]: {
        padding: "20px 20px 28px",
      },
    },
    headerContainer: {
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
    },
    headerTitle: {
      marginTop: theme.spacing(1.25),
      marginBottom: theme.spacing(1.5),
    },
  }),
  { name: "lockWrapper" }
);

const NewLockWrapper: FC<NewLockProps> = ({
  mainPage,
  configure,
  children,
}) => {
  const classes = useStyles();

  return (
    <div className={classes.root}>
      {!mainPage && <GoBackButton />}
      <div className={classes.cardContainer}>
        <div className={classes.headerContainer}>
          <img src={LockIcon} alt="lock icon" />
          <Typography className={classes.headerTitle} variant="h5">
            {configure ? "Configure Lock" : "Create New Lock"}
          </Typography>
        </div>
        {children}
      </div>
    </div>
  );
};

export default NewLockWrapper;
