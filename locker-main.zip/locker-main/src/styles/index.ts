import { createTheme, Theme } from "@material-ui/core";

export const createMuiTheme = (): Theme => {
  return createTheme({
    overrides: {
      MuiCssBaseline: {},
      MuiButton: {
        root: {
          fontSize: "1rem",
          fontFamily: "Poppins, Arial, sans-serif",
          textTransform: "none",
          borderRadius: "100px",
          padding: "20px 35px",
        },
        sizeLarge: {
          padding: "20px 52px",
          fontSize: "1.125rem",
        },
        sizeSmall: {
          padding: "9px 18px",
        },
        contained: {
          color: "#8563F1",
          backgroundColor: "#FFFFFF",
          boxShadow: "0 0 2px #8563F1",
          "&:hover": {
            backgroundColor: "#8563F1",
            color: "#FFFFFF",
          },
          "&.Mui-disabled": {
            color: "#0A052D",
            fontWeight: 500,
          },
        },
      },
      MuiTypography: {
        paragraph: {
          fontFamily: "Poppins, Arial, sans-serif",
        },
        colorPrimary: {
          color: "#0A052D",
        },
        colorSecondary: {
          color: "#40405B",
        },
        body1: {
          fontWeight: 500,
        },
        body2: {
          fontSize: "0.75rem",
          letterSpacing: "0.01em",
          fontWeight: 500,
        },
        h1: {
          fontFamily: "Poppins, Arial, sans-serif",
          fontWeight: "bold",
          fontSize: "3.625rem",
          color: "#0A052D",
        },
        h5: {
          fontFamily: "Poppins, Arial, sans-serif",
          fontWeight: "bold",
          fontSize: "1.5rem",
          color: "#0A052D",
        },
      },
      MuiLink: {
        root: {
          color: "#5538EE",
          cursor: "pointer",
        },
      },
      MuiCheckbox: {
        root: {
          // color: "#5538EE",
          borderRadius: 50,
        },
        // under question
        colorPrimary: {
          color: "#5538EE",
        },
        colorSecondary: {
          color: "#8563F1",
        },
      },
      MuiTooltip: {
        tooltip: {
          fontFamily: "Poppins, Arial, sans-serif",
          backgroundColor: "#EAE0FF",
          color: "#40405B",
          fontSize: 12,
        },
      },
    },
    typography: {
      fontFamily: "Poppins, Arial, sans-serif",
      button: {
        fontSize: "1,125rem",
      },
    },
    palette: {
      type: "light",
      primary: {
        main: "#8563F1",
      },
      secondary: {
        main: "#5538EE",
      },
      error: {
        main: "#E92856",
        light: "#F57279",
      },
    },
  });
};

export const theme = createMuiTheme();
