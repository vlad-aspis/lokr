import Web3Modal from "web3modal";
import { theme } from "../styles";

const providerOptions = {};

const web3Modal = new Web3Modal({
  cacheProvider: true, // optional
  providerOptions, // required
  theme: {
    background: theme.palette.background.paper,
    main: theme.palette.text.primary,
    secondary: theme.palette.text.secondary,
    border: theme.palette.divider,
    hover: theme.palette.action.hover,
  },
});

export default web3Modal;
