import React, { FC, useEffect } from "react";
import { Button, makeStyles, Typography } from "@material-ui/core";
import GoBackButton from "../../components/GoBackButton/GoBackButton";
import { ReactComponent as ClappingSVG } from "../../assets/svgs/icon_clapping.svg";
import { useQuery } from "react-query";
import { API } from "../../core/api/API";
import { useParams } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { AppStore } from "../../@redux/reducers";
import { setIsLoading } from "../../@redux/actions";
import { LOCKER_MAIN_NET, LOCKER_RINKEBY } from "../../core/api/Service";

const useStyles = makeStyles(
  (theme) => ({
    root: {
      width: 555,
      height: 520,
      padding: "0 40px 28px",
      margin: "0 auto",
      backgroundColor: "#FFFFFF",
      borderRadius: 32,
      position: "relative",
      [theme.breakpoints.down("md")]: {
        width: 300,
      },
    },
    mainWrapper: {
      paddingTop: 60,
      width: "100%",
      height: "100%",
      display: "flex",
      flexDirection: "column",
      justifyContent: "center",
      alignItems: "center",
    },
    mt60: {
      marginTop: 60,
    },
    underText: {
      textAlign: "center",
      marginBottom: 24,
    },
    exploreButton: {
      [theme.breakpoints.down("md")]: {
        textAlign: "center",
        padding: "16px 32px",
      },
    },
  }),
  { name: "LockupsFinalPage" }
);

const LockupsFinalPage: FC = () => {
  const classes = useStyles();
  const params = useParams() as any;
  const userAddress = useSelector((state: AppStore) => state.userAddress);
  const amount = useSelector((state: AppStore) => state.successedData?.amount);
  const dispatch = useDispatch();

  const { data: tokenSymbol } = useQuery(
    ["getTokenSymbol", params.address],
    () => {
      return API.Service.getTokenSymbol(params.address);
    },
    {
      enabled: !!params.address && !!userAddress,
    }
  );

  const exploreLink = {
    "rinkeby test": "rinkeby",
    ethereum: "",
  } as any;

  const exploreContract = {
    "rinkeby test": LOCKER_RINKEBY,
    ethereum: LOCKER_MAIN_NET,
  } as any;

  useEffect(() => {
    dispatch(setIsLoading(false));
  }, [dispatch]);

  return (
    <div className={classes.root}>
      <GoBackButton />
      <div className={classes.mainWrapper}>
        <ClappingSVG />
        <Typography className={classes.mt60} variant="h5">
          Congratulations!
        </Typography>
        <Typography className={classes.underText}>
          You’ve successfully locked {amount} {tokenSymbol}
        </Typography>
        <Button
          className={classes.exploreButton}
          href={`https://${exploreLink[params.chain]}.etherscan.io/address/${
            exploreContract[params.chain]
          }#code`}
          target="_blank"
          variant="contained"
          size="large"
        >
          Explore Contract
        </Button>
      </div>
    </div>
  );
};

export default LockupsFinalPage;
