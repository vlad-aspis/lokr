import { CSSProperties } from "react";

export const titleFont: CSSProperties = {
  fontWeight: 600,
  fontSize: "0.875rem",
};

export const tableHover: CSSProperties = {
  border: "1px solid #8563F1",
  boxShadow: "0px 10px 20px -10px rgba(15, 15, 15, 0.1)",
  borderRadius: 12,
};
