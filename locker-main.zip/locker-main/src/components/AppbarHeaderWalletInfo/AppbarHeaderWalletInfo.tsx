import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { AppStore } from "../../@redux/reducers";
import { shortenWalletAddress } from "../../helpers/shortenWalletAddress";
import { Button, makeStyles, Typography } from "@material-ui/core";
import { ReactComponent as MaskSVG } from "../../assets/svgs/Mask-Group.svg";
import { initProvider } from "../../helpers/provider";
import web3Modal from "../../helpers/web3modal";
import { ChainsCurrency } from "../../constatns/chains";
import { API } from "../../core/api/API";

const useStyles = makeStyles(
  (theme) => ({
    root: {},
    walletInfoContainer: {
      minWidth: 280,
      height: 52,
      paddingLeft: 28,
      paddingRight: "auto",
      position: "absolute",
      left: -129,
      zIndex: -1,
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      backgroundColor: "#EDF0F2",
      borderRadius: 100,
      [theme.breakpoints.down("xs")]: {
        left: -87,
        paddingLeft: 8,
      },
    },
    unlockBtn: {
      maxHeight: 52,
      width: 170,
      padding: "18px 30px",
    },
    addressLogoContainer: {
      width: 170,
      height: 52,
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      backgroundColor: "#FFF",
      borderRadius: 100,
      position: "relative",
    },
    address: {
      margin: theme.spacing(0, 2),
    },
  }),
  { name: "AppbarHeaderWalletInfo" }
);

const AppbarHeaderWalletInfo = () => {
  const classes = useStyles();
  const [balance, setBalance] = useState<number>();

  const address = useSelector((state: AppStore) => state.userAddress);
  const chainId = useSelector((state: AppStore) => state.userChainId);

  const connectProvider = async () => {
    web3Modal.clearCachedProvider();
    const provider = await web3Modal.connect();
    initProvider(provider);
  };

  useEffect(() => {
    if (!!address) {
      (async () => {
        setBalance(await API.Account.getBalance(address!));
      })();
    }
  }, [address, chainId]);

  return (
    <>
      {address ? (
        <div className={classes.addressLogoContainer}>
          <div className={classes.walletInfoContainer}>
            <Typography variant="body1">
              {balance && balance.toFixed(3)}{" "}
              <b>{chainId && ChainsCurrency[chainId!]}</b>
            </Typography>
          </div>

          <Typography className={classes.address} variant="body1">
            {" "}
            {address && shortenWalletAddress(address)}
          </Typography>
          <MaskSVG />
        </div>
      ) : (
        <Button
          className={classes.unlockBtn}
          variant="contained"
          color="primary"
          onClick={connectProvider}
        >
          Unlock Wallet
        </Button>
      )}
    </>
  );
};

export default AppbarHeaderWalletInfo;
