import React from "react";
import { Redirect, Route, Switch } from "react-router-dom";
import LockupsMainPage from "../pages/LockupsMainPage/LockupsMainPage";
import { makeStyles } from "@material-ui/core";
import NewLockWrapper from "../components/NewLockWrapper/NewLockWrapper";
import LockupsTypePage from "../pages/LockupsTypePage/LockupsTypePage";
import LockupsAddressPage from "../pages/LockupsAddressPage/LockupsAddressPage";
import ConfigureLockPage from "../pages/ConfigureLockPage/ConfigureLockPage";
import LockupsFinalPage from "../pages/LockupsFinalPage/LockupsFinalPage";
import { useSelector } from "react-redux";
import { AppStore } from "../@redux/reducers";

const useStyles = makeStyles(
  (theme) => ({
    root: {
      paddingTop: theme.spacing(8),
    },
  }),
  { name: "ContentMainContainer" }
);

const AppRouter = () => {
  const classes = useStyles();

  const successedData = useSelector((state: AppStore) => state.successedData);

  return (
    <div className={classes.root}>
      <Switch>
        <Route exact path="/lockups" component={LockupsMainPage} />
        <Route
          exact
          path="/lockups/new/:chain/"
          render={() => (
            <NewLockWrapper>
              <LockupsTypePage />
            </NewLockWrapper>
          )}
        />
        <Route
          exact
          path="/lockups/new/:chain/:type"
          render={() => (
            <NewLockWrapper>
              <LockupsAddressPage />
            </NewLockWrapper>
          )}
        />
        <Route
          exact
          path="/lockups/new/:chain/:type/:address"
          render={() => (
            <NewLockWrapper configure>
              <ConfigureLockPage />
            </NewLockWrapper>
          )}
        />

        {successedData && successedData.success && (
          <Route
            exact
            path="/lockups/new/:chain/:type/:address/success"
            render={() => <LockupsFinalPage />}
          />
        )}
        <Redirect to="/lockups" />
      </Switch>
    </div>
  );
};

export default AppRouter;
