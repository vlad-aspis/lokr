export enum BasePeriod {
  HOUR = "Hour",
  DAY = "Day",
  MONTH = "Month",
  YEAR = "Year",
}

export const BasePeriodMilliseconds = {
  [BasePeriod.HOUR]: 3600000,
  [BasePeriod.DAY]: 86400000,
  [BasePeriod.MONTH]: 2629800000,
  [BasePeriod.YEAR]: 31557600000,
};
